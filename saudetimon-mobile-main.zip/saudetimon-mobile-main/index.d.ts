declare module '*.png';
declare module 'modal-react-native-web';
