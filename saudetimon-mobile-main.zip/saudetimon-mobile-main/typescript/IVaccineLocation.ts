export default interface IVaccineLocation {
  id: number;
  name: string;
  helperText: string;
  picture: string;
  url: string;
}
