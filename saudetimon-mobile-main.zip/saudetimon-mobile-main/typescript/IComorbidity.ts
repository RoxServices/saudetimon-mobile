export default interface IComorbidity {
  id: number;
  comorbidity: string;
}
