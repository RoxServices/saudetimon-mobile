export default interface IDoubt {
  id: number;
  question: string;
  answer: string;
}
