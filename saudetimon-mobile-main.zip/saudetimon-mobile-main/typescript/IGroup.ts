export default interface IGroup {
  id: number;
  group: string;
}
