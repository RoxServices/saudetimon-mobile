export default interface IPhone {
  id: number;
  name: string;
  phone: string;
}
